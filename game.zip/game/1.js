let button =document.getElementById('aaa');
//alert(a);
button.addEventListener('click', ddd);
function ddd() {
	alert("dsfs");
}
